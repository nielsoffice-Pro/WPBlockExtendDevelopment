import { __ } from '@wordpress/i18n';
import { useBlockProps } from '@wordpress/block-editor';
import { TextControl } from '@wordpress/components';

export default function Edit({ attributes, setAttributes }) {
	const blockProps = useBlockProps();
	const { name, age } = attributes;

	return (
		<div {...blockProps}>
			<p>{__('Myquery – hello from the editor!', 'myquery')}</p>

			<TextControl
				label="Name"
				value={name}
				onChange={(value) => setAttributes({ name: value || '' })}
			/>

			<TextControl
				label="Age"
				type="number"
				value={age}
				onChange={(value) => setAttributes({ age: parseInt(value) || 0 })}
			/>
		</div>
	);
}
