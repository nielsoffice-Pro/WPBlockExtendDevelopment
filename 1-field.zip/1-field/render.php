<?php

// function myquery_render_callback($attributes) {

// 	$search = isset($attributes['searchKeyword']) ? sanitize_text_field($attributes['searchKeyword']) : '';

// 	$args = array(
// 		'post_type' => 'post',
// 		'posts_per_page' => 5,
// 	);

// 	if (!empty($search)) {
// 		$args['s'] = $search;
// 	}

// 	$query = new WP_Query($args);

// 	if ($query->have_posts()) {
// 		while ($query->have_posts()) {
// 			$query->the_post();
// 			var_dump(get_the_title()); // Debug output of post titles
// 		}
// 		wp_reset_postdata();
// 	} else {
// 		var_dump('No posts found.');
// 	}

// 	// This is still needed to avoid block breaking
// 	return ''; // or return ob_get_clean() if you add output buffering later

// }

function myquery_render_callback($attributes) {
	echo '<pre>';
	var_dump($attributes);
	echo '</pre>';

	// You can still do your query logic here if you want
	return '';
}
