import { useBlockProps } from '@wordpress/block-editor';

export default function save({ attributes }) {
	const { name, age } = attributes;
	const blockProps = useBlockProps.save();

	return (
		<div {...blockProps}>
			<p>Name: {name || 'N/A'}</p>
			<p>Age: {age || 'N/A'}</p>
		</div>
	);
}
