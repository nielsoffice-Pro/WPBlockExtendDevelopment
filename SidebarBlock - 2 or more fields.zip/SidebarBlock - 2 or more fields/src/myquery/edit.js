import { __ } from '@wordpress/i18n';
import { useBlockProps, InspectorControls } from '@wordpress/block-editor';
import { PanelBody, TextControl } from '@wordpress/components';

export default function Edit({ attributes, setAttributes }) {
	const blockProps = useBlockProps();
	const { name, age } = attributes;

	return (
		<>
			<div {...blockProps}>
				<p>{__('Myquery – hello from the editor!', 'myquery')}</p>
				<p>Name: {name}</p>
				<p>Age: {age}</p>
			</div>

			<InspectorControls>
				<PanelBody title={__('User Info', 'myquery')} initialOpen={true}>
					<TextControl
						label={__('Name', 'myquery')}
						value={name}
						onChange={(value) => setAttributes({ name: value })}
					/>
					<TextControl
						label={__('Age', 'myquery')}
						type="number"
						value={age}
						onChange={(value) => setAttributes({ age: parseInt(value) || 0 })}
					/>
				</PanelBody>
			</InspectorControls>
		</>
	);
}
