import { __ } from '@wordpress/i18n';
import { useBlockProps } from '@wordpress/block-editor';
import { TextControl } from '@wordpress/components';

export default function Edit({ attributes, setAttributes }) {
	const blockProps = useBlockProps();

	return (
		<div {...blockProps}>
			<p>{__('Myquery – hello from the editor!', 'myquery')}</p>
			<TextControl
				type="number"
				label="Age"
				value={attributes.age}
				onChange={(value) => setAttributes({ age: parseInt(value) || 0 })}
			/>

		</div>
	);
}
