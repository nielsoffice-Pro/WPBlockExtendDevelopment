import { useBlockProps } from '@wordpress/block-editor';

export default function save({ attributes }) {

	const blockProps = useBlockProps.save();

	return (
		<div {...blockProps}>
			<p>Myquery – hello from the saved content!</p>
			<p>Age: {attributes.age}</p>
		</div>
	);
}
